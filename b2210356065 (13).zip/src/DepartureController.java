public class DepartureController {
}

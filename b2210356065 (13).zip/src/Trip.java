public class Trip {
}
